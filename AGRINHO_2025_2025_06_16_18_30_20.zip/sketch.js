let car;
let animals = [];
let animalSpeed = 3;
let score = 0;
let gameOver = false;
let gameStarted = false;
let youWin = false;
let button;

function setup() {
  createCanvas(600, 400);
  button = createButton('Iniciar');
  button.position(width / 2 - 50, height / 2 + 50);
  button.size(100, 40);
  button.mousePressed(startGame);
  textAlign(CENTER, CENTER);
  textSize(12);
  textWrap(WORD);
}

function draw() {
  if (!gameStarted) {
    drawCover();
  } else {
    gameLoop();
  }
}

function drawCover() {
  background(50);
  fill(255, 0, 0);
  textSize(36);
  text('CUIDADO COM OS ANIMAIS!', width / 2, height / 3);

  fill(255);
  textSize(24);
  text('Evite atropelar os animais!', width / 2, height / 2);
}

function startGame() {
  gameStarted = true;
  button.hide();
  car = new Car();
  animals = [];
  score = 0;
  gameOver = false;
  youWin = false;
  loop();
}

function gameLoop() {
  background(50);
  drawRoad();

  if (!gameOver && !youWin) {
    car.update();
    car.display();

    if (frameCount % 60 === 0) {
      animals.push(new Animal());
    }

    for (let i = animals.length - 1; i >= 0; i--) {
      animals[i].update();
      animals[i].display();

      if (animals[i].hits(car)) {
        gameOver = true;
      }

      if (animals[i].offScreen()) {
        animals.splice(i, 1);
        score++;
      }
    }

    fill(0);
    textSize(24);
    textAlign(LEFT, TOP);
    text('Score: ' + score, 10, 10);

    if (score >= 30) {
      youWin = true;
    }

  } else if (gameOver) {
    textSize(32);
    fill(0);
    textAlign(CENTER, CENTER);
    text('Game Over!', width / 2, height / 2);
    textSize(20);
    fill(0);
    text('Pressione R para reiniciar', width / 2, height / 2 + 40);
  } else if (youWin) {
    textSize(32);
    fill(0);
    textAlign(CENTER, CENTER);
    text('Parabéns! Você salvou todos os animais! 🐄🎉', width / 2, height / 2);
    textSize(20);
    fill(0);
    text('Pressione R para jogar novamente', width / 2, height / 2 + 40);
  }

  // Balão no canto superior direito com estatística
  let message = "Nos últimos 5 anos, os atropelamentos de animais diminuíram 20% graças à conscientização e medidas de segurança.";
  let maxBubbleWidth = 200;
  let padding = 8;

  textSize(12);
  textAlign(LEFT, TOP);
  let lines = splitMessageToLines(message, maxBubbleWidth - padding * 2);
  let bubbleH = lines.length * 16 + padding * 2;

  let bubbleW = maxBubbleWidth;
  let x = width - bubbleW - 10;
  let y = 140;

  drawSpeechBubbleMultiline(x, y, message, bubbleW, bubbleH, padding);
}

function splitMessageToLines(msg, maxWidth) {
  let words = msg.split(' ');
  let lines = [];
  let currentLine = '';

  for (let i = 0; i < words.length; i++) {
    let testLine = currentLine.length === 0 ? words[i] : currentLine + ' ' + words[i];
    let testWidth = textWidth(testLine);
    if (testWidth > maxWidth && currentLine.length > 0) {
      lines.push(currentLine);
      currentLine = words[i];
    } else {
      currentLine = testLine;
    }
  }
  if (currentLine.length > 0) {
    lines.push(currentLine);
  }
  return lines;
}

function drawSpeechBubbleMultiline(x, y, msg, bubbleW, bubbleH, padding) {
  fill(255);
  stroke(0);
  rect(x, y - bubbleH - 24, bubbleW, bubbleH, 10);
  triangle(x + 20, y - 24, x + 30, y - 6, x + 10, y - 6);

  fill(0);
  noStroke();
  textAlign(LEFT, TOP);
  textSize(12);

  let lines = splitMessageToLines(msg, bubbleW - padding * 2);

  for (let i = 0; i < lines.length; i++) {
    text(lines[i], x + padding, y - bubbleH - 24 + padding + i * 16);
  }
}

function drawRoad() {
  fill(150);
  rect(100, 0, width - 200, height);

  fill(200, 200, 0);
  rect(50, 0, 50, height);
  rect(width - 100, 0, 50, height);

  fill(255);
  for (let i = 0; i < height; i += 60) {
    rect(width / 2 - 10, i, 20, 40);
  }

  stroke(255);
  strokeWeight(6);
  line(width / 2, 0, width / 2, height);

  strokeWeight(2);
  line(100, 0, 100, height);
  line(width - 100, 0, width - 100, height);
}

class Car {
  constructor() {
    this.x = width / 2;
    this.y = height - 100;
    this.width = 60;
    this.height = 40;
    this.speed = 5;
  }

  update() {
    if (keyIsDown(LEFT_ARROW)) this.x -= this.speed;
    if (keyIsDown(RIGHT_ARROW)) this.x += this.speed;
    this.x = constrain(this.x, 100, width - 150);
  }

  display() {
    textSize(60);
    fill(0);
    text('🚗', this.x + this.width / 2, this.y + this.height / 2);
  }
}

class Animal {
  constructor() {
    this.x = random(100, width - 150);
    this.y = -20;
    this.size = 48;
    this.speed = animalSpeed;
  }

  update() {
    this.y += this.speed;
  }

  display() {
    textSize(this.size);
    fill(0);
    text('🐄', this.x, this.y);
  }

  hits(car) {
    let d = dist(this.x, this.y, car.x + car.width / 2, car.y + car.height / 2);
    return d < this.size / 2 + car.width / 2;
  }

  offScreen() {
    return this.y > height + this.size;
  }
}

function keyPressed() {
  if (key === 'r' || key === 'R') {
    gameOver = false;
    youWin = false;
    animals = [];
    score = 0;
    loop();
  }
}





